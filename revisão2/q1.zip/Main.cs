using System; 

public class Program {

  public static void Main(string[] args) {
  Console.WriteLine("Digite os coeficientes a, b, e c de uma equação do II grau");
  int A = int.Parse(Console.ReadLine());
  int B = int.Parse(Console.ReadLine());
  int C = int.Parse(Console.ReadLine());
  int D = int.Parse(Console.ReadLine());
  var m1 = Math.Max(A,B,C,D);
  var m2 = Math.Min(A,B,C,D);
  Console.WriteLine(m1);
}
}