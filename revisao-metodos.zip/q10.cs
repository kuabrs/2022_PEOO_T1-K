using System; 

public class Program {
public static string Vogais(string s){
  int z = -1;
  int a = s.Length;
  int b = 0;
  while(b<=a){
    ;
    b++;
  }
 return z;
  }
    
  public static void Main(string[] args) {
    Console.WriteLine("Escreva dois numeros:");
    string s = Console.ReadLine();
    Console.WriteLine(Vogais(s));
  
  }
}